import React from 'react';
import { ChevronRight, Globe, Code2, Smartphone } from 'lucide-react';
import { useTranslation } from 'react-i18next';

const MobileSettingsApp: React.FC = () => {
  const { i18n } = useTranslation();
  return (
    <div className="bg-[#f2f2f7] h-full p-4 pt-8 text-black font-sans">
      <h1 className="text-3xl font-bold mb-6 px-2 text-black">Settings</h1>
      <div className="bg-white rounded-xl overflow-hidden mb-6 border">
        <button onClick={() => i18n.changeLanguage(i18n.language === 'ar' ? 'en' : 'ar')} className="w-full flex items-center justify-between p-4 active:bg-gray-50">
          <div className="flex items-center gap-3"><div className="bg-blue-500 p-1.5 rounded-md text-white"><Globe size={20} /></div><span className="font-medium text-[17px]">Language / اللغة</span></div>
          <div className="flex items-center gap-2 text-gray-400"><span>{i18n.language === 'ar' ? 'العربية' : 'English'}</span><ChevronRight size={18} /></div>
        </button>
      </div>
      <div className="bg-white rounded-xl overflow-hidden border">
        <div className="flex items-center justify-between p-4 border-b">
          <div className="flex items-center gap-3"><Code2 className="text-blue-500" /><span>Web Development</span></div>
          <ChevronRight size={18} className="text-gray-300" />
        </div>
        <div className="flex items-center justify-between p-4">
          <div className="flex items-center gap-3"><Smartphone className="text-green-500" /><span>Mobile Development</span></div>
          <ChevronRight size={18} className="text-gray-300" />
        </div>
      </div>
    </div>
  );
};

export default MobileSettingsApp;