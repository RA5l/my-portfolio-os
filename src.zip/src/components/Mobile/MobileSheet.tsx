import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import MobileNotesApp from './MobileNotesApp';
import MobileFilesApp from './MobileFilesApp';
import MobilePhotosApp from './MobilePhotosApp';
import MobileProjectDetail from './MobileProjectDetail';
import MobileSkillsApp from './MobileSkillsApp';

interface MobileSheetProps {
  isOpen: boolean;
  onClose: () => void;
  activeApp: string | null;
  children?: React.ReactNode;
}

const MobileSheet: React.FC<MobileSheetProps> = ({ isOpen, onClose, activeApp, children }) => {
  
  // تعريف تطبيقات النظام الأساسية
  const systemApps = ['about', 'resume', 'skills', 'projects', 'photos'];
  const isProject = activeApp && !systemApps.includes(activeApp);

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ y: '100%' }}
          animate={{ y: 0 }}
          exit={{ y: '100%' }}
          transition={{ type: 'spring', damping: 25, stiffness: 200 }}
          drag="y"
          dragConstraints={{ top: 0 }}
          dragElastic={0.1}
          onDragEnd={(_, info) => {
            // إغلاق النافذة عند سحبها للأسفل لمسافة معينة
            if (info.offset.y > 150) onClose();
          }}
          className="fixed inset-0 z-[500] bg-white shadow-2xl overflow-hidden flex flex-col"
          style={{ borderRadius: '32px 32px 0 0' }}
        >
          {/* iOS Handle - مقبض السحب العلوي */}
          <div className="w-full flex justify-center pt-3 pb-2 cursor-grab active:cursor-grabbing flex-shrink-0 bg-transparent z-[60]">
            <div className="w-10 h-1.5 bg-gray-300 rounded-full" />
          </div>

          <div className="flex-1 overflow-y-auto">
            {children ?? (
              <>
                {/* تطبيق الملاحظات - About */}
                {activeApp === 'about' && <MobileNotesApp onClose={onClose} />}
                
                {/* تطبيق الملفات - Resume */}
                {activeApp === 'resume' && <MobileFilesApp onClose={onClose} />}
                
                {/* تطبيق المحفظة - Skills (تم استبدال الإعدادات هنا) */}
                {activeApp === 'skills' && <MobileSkillsApp onClose={onClose} />}
                
                {/* تطبيق الصور - Photos */}
                {activeApp === 'photos' && <MobilePhotosApp onClose={onClose} />}
                
                {/* عرض تفاصيل المشروع عند النقر على مشروع من المجلد */}
                {isProject && <MobileProjectDetail projectId={activeApp} onClose={onClose} />}

                {/* حالة عرض مجلد المشاريع فارغاً */}
                {activeApp === 'projects' && (
                  <div className="flex items-center justify-center h-full text-gray-400 text-[13px] italic px-10 text-center">
                    Select a project from the folder to see details
                  </div>
                )}
              </>
            )}
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default MobileSheet;